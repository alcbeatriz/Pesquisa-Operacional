#1. Faça um programa que escreva “Olá mundo”.
print ('Olá mundo')