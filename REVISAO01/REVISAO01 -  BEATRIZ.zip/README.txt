Semestre EXTEMPORÂNEO - PESQUISA OPERACIONAL -  SISTEMA OPERACIONAL: Windows 10 x64 IDE: Visual Studio Code

Exercícios: Linguagem: Python 3.9